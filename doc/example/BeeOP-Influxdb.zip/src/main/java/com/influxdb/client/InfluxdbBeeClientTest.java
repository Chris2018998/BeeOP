package com.influxdb.client;

import cn.beeop.BeeObjectException;
import cn.beeop.BeeObjectHandle;
import cn.beeop.BeeObjectSource;
import cn.beeop.BeeObjectSourceConfig;

public class InfluxdbBeeClientTest {
    public static void main(String[]agrgs){
        BeeObjectSourceConfig config = new BeeObjectSourceConfig();
        config.setUsername("root");
        config.setPassword("root");
        config.setServerUrl("http://localhost:8086");
        config.setObjectFactory(new InfluxdbBeeClientFactory());
        config.setObjectInterfaces(new Class[]{InfluxDBClient.class});
        BeeObjectSource obs = null;
        BeeObjectHandle handle=null;

        try {
            obs = new BeeObjectSource(config);
            handle=obs.getObject();
            testInfluxDB((InfluxDBClient)handle);
        } catch (BeeObjectException e) {
            e.printStackTrace();
        } finally {
            if(handle!=null)
                try{handle.close();} catch (BeeObjectException e) {}
            if(obs!=null)obs.close();
        }
    }

    private static void testInfluxDB(InfluxDBClient influxDBClient){
        //test......
    }
}
